# global static vars
code_type = 'utf-8'
int_word_len = 4
endian = 'little'
header_size = 20
