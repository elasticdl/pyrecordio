from recordio.recordio.file import File

__all__ = ['File']
